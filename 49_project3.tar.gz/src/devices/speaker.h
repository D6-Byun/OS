#ifndef DEVICES_SPEAKER_H
#define DEVICES_SPEAKER_H

void speaker_on (int frequency);
void speaker_off (void);
void speaker_beep (void);

#endif /* devices/speaker.h */
